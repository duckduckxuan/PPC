install sysv_ipc

game.py -> Game Process
player.py -> Player Process

Exécuter game.py et 2 fois player.py dans trois terminals.
